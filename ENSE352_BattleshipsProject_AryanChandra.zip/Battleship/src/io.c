#include "../include/io.h"
#include <stdio.h>


void displaySea(void)
{
		printf("Displaying the Sea \n");
}